# TechStore API Documentation

## Base URL
```
http://localhost:5000/api
```

## Authentication

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <token>
```

---

## 🔐 Authentication Endpoints

### Register User
Create a new user account.

**Request:**
```http
POST /auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securePassword123"
}
```

**Response (201 Created):**
```json
{
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com"
  }
}
```

**Error Response (400):**
```json
{
  "message": "User already exists"
}
```

---

### Login User
Authenticate and get JWT token.

**Request:**
```http
POST /auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securePassword123"
}
```

**Response (200 OK):**
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com"
  }
}
```

**Error Response (401):**
```json
{
  "message": "Invalid credentials"
}
```

---

## 🛍️ Product Endpoints

### Get All Products
Retrieve list of all available products.

**Request:**
```http
GET /products
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "Laptop",
    "description": "High-performance laptop for work and gaming",
    "price": 999.99,
    "image": "🖥️",
    "stock": 10,
    "created_at": "2024-01-15T10:30:00.000Z"
  },
  {
    "id": 2,
    "name": "Smartphone",
    "description": "Latest smartphone with advanced features",
    "price": 799.99,
    "image": "📱",
    "stock": 20,
    "created_at": "2024-01-15T10:30:00.000Z"
  }
]
```

---

### Get Single Product
Retrieve details for a specific product.

**Request:**
```http
GET /products/:id
```

**Parameters:**
- `id` (integer, required) - Product ID

**Response (200 OK):**
```json
{
  "id": 1,
  "name": "Laptop",
  "description": "High-performance laptop for work and gaming",
  "price": 999.99,
  "image": "🖥️",
  "stock": 10,
  "created_at": "2024-01-15T10:30:00.000Z"
}
```

**Error Response (404):**
```json
{
  "message": "Product not found"
}
```

---

## 🛒 Cart Endpoints

### Validate Cart Items
Verify that cart items exist and check pricing/stock.

**Request:**
```http
POST /cart/validate
Content-Type: application/json

{
  "items": [
    { "id": 1, "quantity": 2 },
    { "id": 3, "quantity": 1 }
  ]
}
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "price": 999.99,
    "stock": 10
  },
  {
    "id": 3,
    "price": 199.99,
    "stock": 30
  }
]
```

---

## 📦 Order Endpoints

### Create Order
Place a new order (requires authentication).

**Request:**
```http
POST /orders
Authorization: Bearer <token>
Content-Type: application/json

{
  "items": [
    {
      "id": 1,
      "name": "Laptop",
      "price": 999.99,
      "quantity": 1
    },
    {
      "id": 3,
      "name": "Headphones",
      "price": 199.99,
      "quantity": 2
    }
  ],
  "totalAmount": 1399.97
}
```

**Response (201 Created):**
```json
{
  "message": "Order created successfully",
  "orderId": 5,
  "status": "processing"
}
```

**Error Response (401):**
```json
{
  "message": "No token provided"
}
```

**Error Response (400):**
```json
{
  "message": "Invalid order data"
}
```

---

### Get User Orders
Retrieve all orders for the authenticated user.

**Request:**
```http
GET /orders
Authorization: Bearer <token>
```

**Response (200 OK):**
```json
[
  {
    "id": 1,
    "user_id": 1,
    "total_amount": 1299.98,
    "status": "completed",
    "created_at": "2024-01-10T15:30:00.000Z",
    "items": "1:1,3:2"
  },
  {
    "id": 2,
    "user_id": 1,
    "total_amount": 799.99,
    "status": "processing",
    "created_at": "2024-01-15T10:30:00.000Z",
    "items": "2:1"
  }
]
```

---

### Get Order Details
Retrieve details for a specific order.

**Request:**
```http
GET /orders/:id
Authorization: Bearer <token>
```

**Parameters:**
- `id` (integer, required) - Order ID

**Response (200 OK):**
```json
{
  "id": 1,
  "user_id": 1,
  "total_amount": 1299.98,
  "status": "completed",
  "created_at": "2024-01-10T15:30:00.000Z",
  "items": [
    {
      "id": 1,
      "order_id": 1,
      "product_id": 1,
      "quantity": 1,
      "price": 999.99,
      "name": "Laptop",
      "image": "🖥️"
    },
    {
      "id": 2,
      "order_id": 1,
      "product_id": 3,
      "quantity": 2,
      "price": 199.99,
      "name": "Headphones",
      "image": "🎧"
    }
  ]
}
```

**Error Response (404):**
```json
{
  "message": "Order not found"
}
```

---

## 🔑 HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success - Request succeeded |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Missing/invalid token |
| 403 | Forbidden - Token invalid/expired |
| 404 | Not Found - Resource doesn't exist |
| 500 | Server Error - Internal server error |

---

## 📝 Request/Response Examples

### Example: Complete Purchase Flow

**1. Register/Login**
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "securePassword123"
  }'
```

**2. Get Products**
```bash
curl http://localhost:5000/api/products
```

**3. Create Order**
```bash
curl -X POST http://localhost:5000/api/orders \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{
    "items": [
      {"id": 1, "name": "Laptop", "price": 999.99, "quantity": 1}
    ],
    "totalAmount": 999.99
  }'
```

**4. View Orders**
```bash
curl http://localhost:5000/api/orders \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

## 🔒 Security Headers

Include these headers in production:

```
Content-Security-Policy: default-src 'self'
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

---

## Rate Limiting

Implement rate limiting in production:
- 100 requests per 15 minutes per IP
- 50 requests per 15 minutes per authenticated user

---

## Pagination (Future Enhancement)

For product listings, add pagination:

```http
GET /products?page=1&limit=10
```

---

## Filtering (Future Enhancement)

Filter products by price range:

```http
GET /products?minPrice=100&maxPrice=1000
```

---

## Error Handling

All errors return a consistent format:

```json
{
  "message": "Error description",
  "code": "ERROR_CODE",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## Testing with Postman

1. Import the collection from `postman_collection.json`
2. Set `{{baseUrl}}` to `http://localhost:5000/api`
3. Set `{{token}}` after login response
4. Run requests from the collection

---

## Webhook Events (Future)

Events to implement:
- `order.created`
- `order.shipped`
- `order.delivered`
- `payment.completed`

---

Last Updated: June 2026
