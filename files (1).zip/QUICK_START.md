# 🚀 Quick Start Guide

## Get Running in 5 Minutes

### Step 1: Install Dependencies
```bash
npm install
```
⏱️ Takes ~30-60 seconds

### Step 2: Start Server
```bash
npm start
```

You should see:
```
Server running on http://localhost:5000
Database: ecommerce.db
```

### Step 3: Open Browser
Navigate to: **http://localhost:5000**

### Done! 🎉

---

## First Steps

### 1️⃣ Create Account
- Click **Register**
- Enter: Username, Email, Password
- Click **Register**

### 2️⃣ Browse Products
- You'll see 6 sample products
- Click any product for details
- Click **Add to Cart**

### 3️⃣ Go Shopping
- Add items to cart
- Click cart icon to view items
- Click **Proceed to Checkout**

### 4️⃣ Complete Purchase
- Fill in shipping address
- Fill in payment details
- Click **Place Order**
- 🎉 Order confirmed!

### 5️⃣ View Orders
- Click **Account** → **My Orders**
- See all your orders

---

## Sample Test Data

**6 Pre-loaded Products:**
1. 🖥️ Laptop - $999.99
2. 📱 Smartphone - $799.99
3. 🎧 Headphones - $199.99
4. 📱 Tablet - $499.99
5. 📷 Camera - $1299.99
6. ⌚ Smartwatch - $349.99

---

## Troubleshooting

### ❌ Port 5000 in use?
Change port in `server.js` line 9:
```javascript
const PORT = 3000;  // or any other port
```

### ❌ npm install fails?
Try:
```bash
rm -rf node_modules package-lock.json
npm install
```

### ❌ Database issues?
Delete and recreate:
```bash
rm ecommerce.db
npm start
```

### ❌ CORS errors?
Make sure backend is running on `http://localhost:5000`

---

## Development Mode (Auto-reload)

```bash
npm run dev
```
Changes to `server.js` automatically reload

---

## Project Structure (Simple)

```
ecommerce-store/
├── server.js          ← Backend (Express)
├── package.json       ← Dependencies
└── public/
    ├── index.html     ← Frontend page
    ├── styles.css     ← Styling
    └── app.js         ← Frontend logic
```

---

## Key Features at a Glance

| Feature | Status |
|---------|--------|
| User Authentication | ✅ Complete |
| Product Browsing | ✅ Complete |
| Shopping Cart | ✅ Complete |
| Checkout | ✅ Complete |
| Order History | ✅ Complete |
| SQLite Database | ✅ Complete |
| JWT Auth | ✅ Complete |
| Responsive Design | ✅ Complete |

---

## Common Commands

```bash
# Start server
npm start

# Development mode (auto-reload)
npm run dev

# Install dependencies
npm install

# View database
sqlite3 ecommerce.db

# Reset database
rm ecommerce.db && npm start
```

---

## Want to Customize?

### Change Colors
Edit `public/styles.css`:
- Find: `#667eea` (purple)
- Find: `#764ba2` (darker purple)
- Replace with your colors

### Add More Products
Edit `server.js` around line 53:
```javascript
{ name: 'Your Product', price: 99.99, stock: 10, image: '🎯', description: '...' }
```

### Change Store Name
Edit `public/index.html` line 7:
```html
<title>YourStoreName - E-Commerce</title>
```

And line 23:
```html
<div class="logo">🛍️ YourStoreName</div>
```

---

## Next Level: Deployment

### Deploy to Heroku (Free)
```bash
heroku login
heroku create your-app-name
git push heroku main
```

### Deploy to Railway
```bash
railway login
railway init
railway up
```

---

## Need Help?

1. Check `README.md` for detailed docs
2. Check `API_DOCUMENTATION.md` for API details
3. Open browser console (F12) for errors
4. Check terminal for server logs

---

## What's Next?

- ✨ Add product search
- ✨ Implement admin panel
- ✨ Add product reviews
- ✨ Integrate payment gateway (Stripe)
- ✨ Create mobile app

---

**Happy Coding! 🚀**

Start building your dream e-commerce store now!
