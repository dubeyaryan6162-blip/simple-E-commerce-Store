// API Base URL
const API_URL = 'http://localhost:5000/api';

// State
let cart = [];
let products = [];
let currentUser = null;
let selectedQuantity = 1;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadCart();
    checkAuthStatus();
    loadProducts();
});

// ===== AUTH FUNCTIONS =====

async function register() {
    const username = document.getElementById('register-username').value.trim();
    const email = document.getElementById('register-email').value.trim();
    const password = document.getElementById('register-password').value;
    const confirm = document.getElementById('register-confirm').value;

    if (!username || !email || !password || !confirm) {
        showToast('All fields are required', 'error');
        return;
    }

    if (password !== confirm) {
        showToast('Passwords do not match', 'error');
        return;
    }

    if (password.length < 6) {
        showToast('Password must be at least 6 characters', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });

        const data = await response.json();

        if (!response.ok) {
            showToast(data.message || 'Registration failed', 'error');
            return;
        }

        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        currentUser = data.user;
        updateAuthUI();
        clearForm('register');
        showToast('Registration successful! Welcome, ' + username, 'success');
        showProducts();
    } catch (error) {
        showToast('Registration error: ' + error.message, 'error');
    }
}

async function login() {
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    if (!email || !password) {
        showToast('Email and password are required', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (!response.ok) {
            showToast(data.message || 'Login failed', 'error');
            return;
        }

        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        currentUser = data.user;
        updateAuthUI();
        clearForm('login');
        showToast('Login successful! Welcome back, ' + data.user.username, 'success');
        showProducts();
    } catch (error) {
        showToast('Login error: ' + error.message, 'error');
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    cart = [];
    localStorage.removeItem('cart');
    updateAuthUI();
    showToast('Logged out successfully', 'success');
    showProducts();
}

function checkAuthStatus() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    if (token && user) {
        currentUser = JSON.parse(user);
        updateAuthUI();
    } else {
        updateAuthUI();
    }
}

function updateAuthUI() {
    const userMenu = document.getElementById('user-menu');
    const authMenu = document.getElementById('auth-menu');

    if (currentUser) {
        userMenu.classList.remove('hidden');
        authMenu.classList.add('hidden');
        updateCartUI();
    } else {
        userMenu.classList.add('hidden');
        authMenu.classList.remove('hidden');
    }
}

function toggleUserMenu() {
    const userMenu = document.getElementById('user-menu');
    userMenu.classList.toggle('active');
    document.addEventListener('click', closeUserMenu);
}

function closeUserMenu(e) {
    const userMenu = document.getElementById('user-menu');
    if (!userMenu.contains(e.target)) {
        userMenu.classList.remove('active');
        document.removeEventListener('click', closeUserMenu);
    }
}

// ===== PAGE NAVIGATION =====

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    window.scrollTo(0, 0);
}

function showProducts() {
    showPage('products-page');
}

function showProductDetail(productId) {
    const product = products.find(p => p.id == productId);
    if (!product) return;

    selectedQuantity = 1;

    const detailHTML = `
        <div class="product-detail">
            <div class="product-detail-image">${product.image}</div>
            <div class="product-detail-info">
                <h2>${product.name}</h2>
                <div class="price">$${product.price.toFixed(2)}</div>
                <p class="description">${product.description}</p>
                <p class="stock">Stock: <strong>${product.stock}</strong> available</p>
                
                <div class="quantity-selector">
                    <button onclick="decreaseQuantity()">-</button>
                    <input type="number" id="quantity-input" value="${selectedQuantity}" min="1" max="${product.stock}" readonly>
                    <button onclick="increaseQuantity(${product.stock})">+</button>
                </div>

                <button onclick="addToCart(${product.id}, '${product.name}', ${product.price}, ${selectedQuantity})" class="btn btn-primary">
                    Add to Cart
                </button>
                <button onclick="showProducts()" class="btn btn-secondary">Continue Shopping</button>
            </div>
        </div>
    `;

    document.getElementById('product-detail').innerHTML = detailHTML;
    showPage('product-detail-page');
}

function showCart() {
    if (!currentUser) {
        showToast('Please login first', 'error');
        showLoginForm();
        return;
    }

    if (cart.length === 0) {
        document.getElementById('cart-content').innerHTML = `
            <div class="cart-empty">
                <p>Your cart is empty</p>
                <button onclick="showProducts()" class="btn btn-primary">Start Shopping</button>
            </div>
        `;
        showPage('cart-page');
        return;
    }

    let cartHTML = '<div class="cart-items">';
    let total = 0;

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        cartHTML += `
            <div class="cart-item">
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">$${item.price.toFixed(2)} each</div>
                </div>
                <div class="cart-item-quantity">
                    <button onclick="updateCartQuantity(${index}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="updateCartQuantity(${index}, 1)">+</button>
                </div>
                <div class="cart-item-total">$${itemTotal.toFixed(2)}</div>
                <button class="cart-item-remove" onclick="removeFromCart(${index})">Remove</button>
            </div>
        `;
    });

    cartHTML += '</div>';
    cartHTML += `
        <div class="cart-summary">
            <div class="summary-row">
                <span>Subtotal:</span>
                <span>$${total.toFixed(2)}</span>
            </div>
            <div class="summary-row">
                <span>Shipping:</span>
                <span>$${(total > 0 ? 10 : 0).toFixed(2)}</span>
            </div>
            <div class="summary-row total">
                <span>Total:</span>
                <span>$${(total + (total > 0 ? 10 : 0)).toFixed(2)}</span>
            </div>
        </div>
        <div class="cart-actions">
            <button onclick="showCheckout()" class="btn btn-primary">Proceed to Checkout</button>
            <button onclick="showProducts()" class="btn btn-secondary">Continue Shopping</button>
        </div>
    `;

    document.getElementById('cart-content').innerHTML = cartHTML;
    showPage('cart-page');
}

function showCheckout() {
    if (!currentUser) {
        showToast('Please login first', 'error');
        showLoginForm();
        return;
    }

    if (cart.length === 0) {
        showToast('Cart is empty', 'error');
        return;
    }

    let total = 0;
    let itemsHTML = '';

    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        itemsHTML += `
            <div class="checkout-item">
                <span>${item.name} x${item.quantity}</span>
                <span>$${itemTotal.toFixed(2)}</span>
            </div>
        `;
    });

    total += 10; // Shipping

    document.getElementById('checkout-items').innerHTML = itemsHTML;
    document.getElementById('checkout-total').textContent = total.toFixed(2);

    showPage('checkout-page');
}

async function processOrder() {
    if (!currentUser) {
        showToast('Please login first', 'error');
        return;
    }

    const address = document.getElementById('shipping-address').value.trim();
    const city = document.getElementById('shipping-city').value.trim();
    const zip = document.getElementById('shipping-zip').value.trim();
    const cardNumber = document.getElementById('card-number').value.trim();
    const cardExpiry = document.getElementById('card-expiry').value.trim();
    const cardCVV = document.getElementById('card-cvv').value.trim();

    if (!address || !city || !zip || !cardNumber || !cardExpiry || !cardCVV) {
        showToast('Please fill in all required fields', 'error');
        return;
    }

    // Validate card number
    if (cardNumber.length !== 16 || !/^\d+$/.test(cardNumber)) {
        showToast('Invalid card number', 'error');
        return;
    }

    // Validate expiry
    if (!/^\d{2}\/\d{2}$/.test(cardExpiry)) {
        showToast('Invalid expiry date (use MM/YY)', 'error');
        return;
    }

    // Validate CVV
    if (cardCVV.length !== 3 || !/^\d+$/.test(cardCVV)) {
        showToast('Invalid CVV', 'error');
        return;
    }

    const totalAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 10;
    const token = localStorage.getItem('token');

    try {
        const response = await fetch(`${API_URL}/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                items: cart,
                totalAmount
            })
        });

        const data = await response.json();

        if (!response.ok) {
            showToast(data.message || 'Order processing failed', 'error');
            return;
        }

        // Clear cart and show confirmation
        cart = [];
        localStorage.removeItem('cart');
        updateCartUI();

        document.getElementById('confirmation-order-id').textContent = data.orderId;
        document.getElementById('confirmation-status').textContent = data.status;

        showToast('Order placed successfully!', 'success');
        showPage('confirmation-page');
    } catch (error) {
        showToast('Order error: ' + error.message, 'error');
    }
}

async function showOrders() {
    if (!currentUser) {
        showToast('Please login first', 'error');
        showLoginForm();
        return;
    }

    const token = localStorage.getItem('token');

    try {
        const response = await fetch(`${API_URL}/orders`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        const orders = await response.json();

        if (orders.length === 0) {
            document.getElementById('orders-list').innerHTML = `
                <div class="cart-empty">
                    <p>No orders yet</p>
                    <button onclick="showProducts()" class="btn btn-primary">Start Shopping</button>
                </div>
            `;
            showPage('orders-page');
            return;
        }

        let ordersHTML = '';

        for (const order of orders) {
            const orderDetails = await fetch(`${API_URL}/orders/${order.id}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            }).then(r => r.json());

            const date = new Date(order.created_at).toLocaleDateString();

            ordersHTML += `
                <div class="order-card">
                    <div class="order-header">
                        <div>
                            <div class="order-id">Order #${order.id}</div>
                            <div class="order-date">${date}</div>
                        </div>
                        <span class="order-status ${order.status}">${order.status.toUpperCase()}</span>
                    </div>
                    <div class="order-items">
                        ${orderDetails.items.map(item => `
                            <div class="order-item">
                                <span>${item.name} x${item.quantity}</span>
                                <span>$${(item.price * item.quantity).toFixed(2)}</span>
                            </div>
                        `).join('')}
                    </div>
                    <div class="order-total">
                        <span>Total:</span>
                        <span>$${order.total_amount.toFixed(2)}</span>
                    </div>
                </div>
            `;
        }

        document.getElementById('orders-list').innerHTML = ordersHTML;
        showPage('orders-page');
    } catch (error) {
        showToast('Error loading orders: ' + error.message, 'error');
    }
}

function showLoginForm() {
    showPage('login-page');
}

function showRegisterForm() {
    showPage('register-page');
}

// ===== PRODUCTS FUNCTIONS =====

async function loadProducts() {
    try {
        const response = await fetch(`${API_URL}/products`);
        products = await response.json();
        displayProducts();
    } catch (error) {
        showToast('Error loading products: ' + error.message, 'error');
    }
}

function displayProducts() {
    const grid = document.getElementById('products-grid');
    grid.innerHTML = '';

    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.onclick = () => showProductDetail(product.id);

        card.innerHTML = `
            <div class="product-image">${product.image}</div>
            <div class="product-info">
                <div class="product-name">${product.name}</div>
                <div class="product-price">$${product.price.toFixed(2)}</div>
                <div class="product-description">${product.description}</div>
                <div class="product-stock">Stock: ${product.stock}</div>
                <button class="btn btn-primary btn-small" onclick="event.stopPropagation(); addToCart(${product.id}, '${product.name}', ${product.price}, 1)">
                    Add to Cart
                </button>
            </div>
        `;

        grid.appendChild(card);
    });
}

// ===== CART FUNCTIONS =====

function addToCart(productId, name, price, quantity) {
    if (!currentUser) {
        showToast('Please login first', 'error');
        showLoginForm();
        return;
    }

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({ id: productId, name, price, quantity });
    }

    saveCart();
    updateCartUI();
    showToast(`Added ${quantity} ${name}(s) to cart`, 'success');
}

function removeFromCart(index) {
    cart.splice(index, 1);
    saveCart();
    updateCartUI();
    showCart();
    showToast('Item removed from cart', 'success');
}

function updateCartQuantity(index, change) {
    cart[index].quantity += change;

    if (cart[index].quantity <= 0) {
        removeFromCart(index);
        return;
    }

    saveCart();
    updateCartUI();
    showCart();
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function loadCart() {
    const saved = localStorage.getItem('cart');
    if (saved) {
        cart = JSON.parse(saved);
    }
}

function updateCartUI() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cart-count').textContent = count;
}

function increaseQuantity(max) {
    if (selectedQuantity < max) {
        selectedQuantity++;
        document.getElementById('quantity-input').value = selectedQuantity;
    }
}

function decreaseQuantity() {
    if (selectedQuantity > 1) {
        selectedQuantity--;
        document.getElementById('quantity-input').value = selectedQuantity;
    }
}

// ===== UTILITY FUNCTIONS =====

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast show ${type}`;

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function clearForm(formType) {
    if (formType === 'login') {
        document.getElementById('login-email').value = '';
        document.getElementById('login-password').value = '';
    } else if (formType === 'register') {
        document.getElementById('register-username').value = '';
        document.getElementById('register-email').value = '';
        document.getElementById('register-password').value = '';
        document.getElementById('register-confirm').value = '';
    }
}
