# TechStore - E-Commerce Application

A complete, production-ready e-commerce platform built with **Express.js**, **SQLite**, and **Vanilla JavaScript**.

## 🎯 Features

✅ **User Authentication**
- User registration and login
- JWT token-based authentication
- Password hashing with bcryptjs
- Session persistence

✅ **Product Catalog**
- Browse all products
- Detailed product pages
- Product images and descriptions
- Real-time stock tracking

✅ **Shopping Cart**
- Add/remove items
- Update quantities
- Persistent cart storage (localStorage)
- Real-time cart count

✅ **Order Management**
- Secure checkout process
- Order history
- Order status tracking
- Order details view

✅ **Database**
- SQLite database with 4 tables
- Relational data structure
- Sample product data included

## 📋 Prerequisites

- **Node.js** (v14.0.0 or higher)
- **npm** (v6.0.0 or higher)
- **Git** (optional)

## 🚀 Quick Start

### 1. Setup (First Time Only)

```bash
# Navigate to project directory
cd ecommerce-store

# Install dependencies
npm install
```

### 2. Start the Server

```bash
# Development mode (with auto-reload)
npm run dev

# Or production mode
npm start
```

You should see:
```
Server running on http://localhost:5000
Database: ecommerce.db
```

### 3. Open the Application

Open your browser and go to:
```
http://localhost:5000
```

## 📁 Project Structure

```
ecommerce-store/
├── server.js                 # Express server & routes
├── package.json             # Dependencies
├── ecommerce.db            # SQLite database (created automatically)
└── public/
    ├── index.html          # Main HTML page
    ├── styles.css          # Styling
    └── app.js              # Frontend JavaScript
```

## 🔧 Configuration

### Change JWT Secret (Important!)

Edit `server.js` line 8:
```javascript
const JWT_SECRET = 'your_secret_key_change_this_in_production';
```

Replace with a strong random string:
```javascript
const JWT_SECRET = 'super_secret_key_12345abcde_change_in_production';
```

### Change Server Port

Edit `server.js` line 9:
```javascript
const PORT = 5000;  // Change to desired port
```

## 🗄️ Database Schema

### Users Table
```sql
CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at DATETIME
)
```

### Products Table
```sql
CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price REAL NOT NULL,
  image TEXT,
  stock INTEGER,
  created_at DATETIME
)
```

### Orders Table
```sql
CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  total_amount REAL NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at DATETIME
)
```

### Order Items Table
```sql
CREATE TABLE order_items (
  id INTEGER PRIMARY KEY,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  price REAL NOT NULL
)
```

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Products
- `GET /api/products` - Get all products
- `GET /api/products/:id` - Get single product

### Cart
- `POST /api/cart/validate` - Validate cart items

### Orders
- `POST /api/orders` - Create new order (requires auth)
- `GET /api/orders` - Get user's orders (requires auth)
- `GET /api/orders/:id` - Get order details (requires auth)

## 👤 Test Accounts

After first run, you can create accounts or use these demo credentials (create them first):

```
Email: demo@example.com
Password: demo123
```

## 🛍️ Usage Guide

### For Customers

1. **Browse Products**
   - View all products on home page
   - Click product card for details
   - See stock availability

2. **Create Account**
   - Click "Register" in navigation
   - Fill in username, email, password
   - Account created and auto-logged in

3. **Shopping**
   - Click "Add to Cart" on any product
   - Adjust quantity on product detail page
   - View cart anytime from navbar

4. **Checkout**
   - Click "Proceed to Checkout"
   - Fill in shipping & payment info
   - Confirm order

5. **View Orders**
   - Click "Account" → "My Orders"
   - See order history and status
   - Track orders

### For Developers

#### Adding Products
Edit `server.js` around line 53, modify the sample products array:

```javascript
const sampleProducts = [
  { 
    name: 'Product Name',
    description: 'Product description',
    price: 99.99,
    image: '🎯',  // Unicode emoji or image URL
    stock: 10
  }
];
```

#### Modifying Styles
Edit `public/styles.css` to customize appearance:
- Colors: Look for `#667eea` and `#764ba2`
- Fonts: Modify `font-family` in `body` selector
- Spacing: Adjust `padding` and `margin` values

#### Extending Features
Add new routes in `server.js`:

```javascript
app.post('/api/reviews', authenticateToken, (req, res) => {
  // Add review logic here
});
```

## 🔒 Security Notes

⚠️ **For Production:**

1. Change JWT_SECRET to a strong random string
2. Use HTTPS instead of HTTP
3. Add input validation on backend
4. Implement rate limiting
5. Add CORS restrictions
6. Use environment variables for sensitive data
7. Add proper error handling
8. Implement payment gateway (Stripe, PayPal)
9. Add SQL injection prevention
10. Implement user session timeout

## 🐛 Troubleshooting

### "Cannot find module" error
```bash
npm install
```

### "Port 5000 already in use"
Change port in `server.js` or kill existing process:
```bash
# On Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# On Mac/Linux
lsof -i :5000
kill -9 <PID>
```

### Cart clears on refresh
Cart is stored in browser's localStorage - this is normal. Use backend sessions for persistence in production.

### Database issues
Delete `ecommerce.db` and restart server to recreate:
```bash
rm ecommerce.db
npm start
```

### CORS errors
Check that server is running on `http://localhost:5000` and frontend is accessing it correctly.

## 📈 Performance Tips

1. **Database Indexing** - Add indexes for frequently queried columns
2. **Pagination** - Add pagination for product listings
3. **Caching** - Implement Redis for session storage
4. **Image Optimization** - Use actual images instead of emojis
5. **Minification** - Minify CSS/JS for production

## 🔄 Deployment

### Heroku
```bash
heroku login
heroku create your-app-name
git push heroku main
```

### Railway
```bash
railway login
railway init
railway up
```

### AWS/DigitalOcean
1. Install Node.js on server
2. Clone repository
3. Install dependencies: `npm install`
4. Use process manager: `pm2 start server.js`
5. Set up reverse proxy (nginx)

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| express | Web framework |
| sqlite3 | Database |
| bcryptjs | Password hashing |
| jsonwebtoken | Authentication tokens |
| cors | Cross-origin requests |
| nodemon | Development auto-reload |

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -am 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Submit pull request

## 📄 License

MIT License - Feel free to use this project for personal or commercial purposes.

## 🆘 Support

For issues, questions, or suggestions:
1. Check the Troubleshooting section
2. Review the API Endpoints
3. Check browser console for errors (F12)
4. Check server logs in terminal

## 🚀 Next Steps

After getting comfortable with the basics:

1. **Add Payment Processing**
   - Integrate Stripe API
   - Process real payments

2. **Implement Admin Panel**
   - Add products
   - View orders
   - Manage inventory

3. **Enhance UI**
   - Add product search
   - Implement filters
   - Add recommendations

4. **Add Features**
   - Product reviews/ratings
   - Wishlist
   - Email notifications
   - Discount codes

5. **Mobile App**
   - React Native or Flutter
   - Connect to same backend

## 🎓 Learning Resources

- Express.js Docs: https://expressjs.com/
- SQLite Docs: https://www.sqlite.org/docs.html
- JWT Auth: https://jwt.io/
- REST API Best Practices: https://restfulapi.net/

---

**Happy Coding! 🎉**

For the latest version, visit: [GitHub Repository]

Last Updated: June 2026
