# 🛠️ Customization & Extension Guide

## How to Customize Your E-Commerce Store

---

## 1. Branding & Colors

### Change Store Name & Logo

**File:** `public/index.html`

```html
<!-- Line 23 -->
<div class="logo">🛒 TechStore</div>  ← Change this

<!-- Line 7 -->
<title>TechStore - E-Commerce Platform</title>  ← Change this too
```

**Example:**
```html
<div class="logo">🎮 GameVault</div>
<title>GameVault - Gaming Products</title>
```

### Change Color Scheme

**File:** `public/styles.css`

Find and replace these colors:
```css
/* Primary Purple */
#667eea  → your_color_1

/* Secondary Purple */
#764ba2  → your_color_2

/* Error Red */
#ff6b6b  → your_error_color

/* Success Green */
#28a745  → your_success_color
```

**Example - Change to Blue Theme:**
```css
/* Replace */
#667eea → #007bff
#764ba2 → #0056b3

/* In gradients */
linear-gradient(135deg, #007bff 0%, #0056b3 100%)
```

### Change Font

**File:** `public/styles.css`

```css
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
```

**Examples:**
```css
/* Modern */
font-family: 'Inter', sans-serif;

/* Elegant */
font-family: 'Poppins', sans-serif;

/* Playful */
font-family: 'Comfortaa', cursive;
```

---

## 2. Adding Products

### Option A: Through Database (Easy)

**File:** `server.js` (Lines 50-65)

```javascript
const sampleProducts = [
  {
    name: 'Product Name',
    description: 'Product description here',
    price: 99.99,
    image: '🎯',  // Any emoji or image URL
    stock: 10
  },
  // Add more...
];
```

**Product Template:**
```javascript
{
  name: 'MacBook Pro',
  description: '16-inch MacBook Pro with M3 Max',
  price: 2499.99,
  image: '💻',  // Or use: 'https://url.to/image.jpg'
  stock: 5
}
```

**Emoji Suggestions:**
- Tech: 💻 🖥️ 📱 ⌚ 🎧
- Fashion: 👕 👗 👞 👜 🕶️
- Food: 🍔 🍕 🍜 🍰 ☕
- Books: 📚 📖 📝 ✏️
- Games: 🎮 🎯 🎲 🃏

### Option B: Add API Endpoint (Advanced)

**File:** `server.js` (Add this route)

```javascript
// Add new product (admin only)
app.post('/api/products', (req, res) => {
  const { name, description, price, image, stock } = req.body;
  
  db.run(
    "INSERT INTO products (name, description, price, image, stock) VALUES (?, ?, ?, ?, ?)",
    [name, description, price, image, stock],
    function(err) {
      if (err) return res.status(500).json({ message: 'Error adding product' });
      res.status(201).json({ id: this.lastID, message: 'Product added' });
    }
  );
});
```

Then call it from frontend:
```javascript
async function addNewProduct() {
  const product = {
    name: 'New Product',
    description: 'Description',
    price: 99.99,
    image: '🎯',
    stock: 10
  };
  
  const response = await fetch('http://localhost:5000/api/products', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product)
  });
  
  const result = await response.json();
  console.log('Product added:', result);
}
```

---

## 3. Custom Pages & Sections

### Add an About Page

**Step 1:** Add to HTML (`public/index.html`)

```html
<!-- Add to nav links -->
<li><a href="#" onclick="showAbout()">About</a></li>

<!-- Add new page -->
<div id="about-page" class="page">
  <h1>About Our Store</h1>
  <p>Welcome to TechStore...</p>
  <button onclick="showProducts()" class="btn">Back to Shopping</button>
</div>
```

**Step 2:** Add to JavaScript (`public/app.js`)

```javascript
function showAbout() {
  showPage('about-page');
}
```

### Add a Contact Page

```html
<div id="contact-page" class="page">
  <div class="contact-form">
    <h2>Contact Us</h2>
    <input type="text" placeholder="Your Name">
    <input type="email" placeholder="Your Email">
    <textarea placeholder="Message"></textarea>
    <button class="btn btn-primary">Send Message</button>
  </div>
</div>
```

---

## 4. Add Product Filters

### Add Category Filter

**Step 1:** Add category field to products

Edit `server.js` (modify CREATE TABLE):

```javascript
db.run(`CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  price REAL NOT NULL,
  image TEXT,
  stock INTEGER DEFAULT 0,
  category TEXT DEFAULT 'General',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);
```

**Step 2:** Update sample products

```javascript
const sampleProducts = [
  { ..., category: 'Computers' },
  { ..., category: 'Phones' },
  { ..., category: 'Accessories' }
];
```

**Step 3:** Add filter UI

```html
<div id="filters" class="filters">
  <select id="category-filter" onchange="filterByCategory()">
    <option value="">All Categories</option>
    <option value="Computers">Computers</option>
    <option value="Phones">Phones</option>
    <option value="Accessories">Accessories</option>
  </select>
</div>
```

**Step 4:** Add filter logic

```javascript
function filterByCategory() {
  const category = document.getElementById('category-filter').value;
  
  let filtered = products;
  if (category) {
    filtered = products.filter(p => p.category === category);
  }
  
  displayFilteredProducts(filtered);
}

function displayFilteredProducts(items) {
  const grid = document.getElementById('products-grid');
  grid.innerHTML = '';
  
  items.forEach(product => {
    // ... same as displayProducts
  });
}
```

---

## 5. Add Product Search

**HTML:**
```html
<div class="search-bar">
  <input type="text" id="search-input" placeholder="Search products..." onkeyup="searchProducts()">
</div>
```

**CSS:**
```css
.search-bar {
  margin-bottom: 2rem;
}

.search-bar input {
  width: 100%;
  max-width: 400px;
  padding: 0.8rem;
  border: 1px solid #ddd;
  border-radius: 0.5rem;
  font-size: 1rem;
}
```

**JavaScript:**
```javascript
function searchProducts() {
  const query = document.getElementById('search-input').value.toLowerCase();
  
  const filtered = products.filter(p => 
    p.name.toLowerCase().includes(query) ||
    p.description.toLowerCase().includes(query)
  );
  
  displayFilteredProducts(filtered);
}
```

---

## 6. Add Product Reviews

### Database Changes

**File:** `server.js`

```javascript
db.run(`CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  rating INTEGER NOT NULL,
  comment TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(product_id) REFERENCES products(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
)`);
```

### API Endpoints

```javascript
// Post review
app.post('/api/reviews', authenticateToken, (req, res) => {
  const { productId, rating, comment } = req.body;
  
  db.run(
    "INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)",
    [productId, req.user.id, rating, comment],
    (err) => {
      if (err) return res.status(500).json({ message: 'Error posting review' });
      res.status(201).json({ message: 'Review posted' });
    }
  );
});

// Get reviews for product
app.get('/api/reviews/:productId', (req, res) => {
  db.all(
    `SELECT r.rating, r.comment, r.created_at, u.username 
     FROM reviews r 
     JOIN users u ON r.user_id = u.id 
     WHERE r.product_id = ? 
     ORDER BY r.created_at DESC`,
    [req.params.productId],
    (err, reviews) => {
      if (err) return res.status(500).json({ message: 'Error loading reviews' });
      res.json(reviews);
    }
  );
});
```

---

## 7. Add Discount Codes

### Database Schema

```javascript
db.run(`CREATE TABLE IF NOT EXISTS coupons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE NOT NULL,
  discount_percent REAL NOT NULL,
  min_amount REAL,
  expires_at DATETIME,
  max_uses INTEGER,
  used INTEGER DEFAULT 0
)`);
```

### Apply Coupon Logic

```javascript
async function applyCoupon() {
  const code = document.getElementById('coupon-code').value;
  const token = localStorage.getItem('token');
  
  const response = await fetch(`${API_URL}/coupons/validate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ code, cartTotal: calculateTotal() })
  });
  
  const result = await response.json();
  if (result.discount) {
    applyDiscount(result.discount);
  }
}
```

---

## 8. Add Wishlist Feature

### Database

```javascript
db.run(`CREATE TABLE IF NOT EXISTS wishlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(product_id) REFERENCES products(id)
)`);
```

### Frontend

```html
<button onclick="addToWishlist(productId)" class="btn-wishlist">❤️ Add to Wishlist</button>
```

```javascript
async function addToWishlist(productId) {
  const token = localStorage.getItem('token');
  
  const response = await fetch(`${API_URL}/wishlist`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ productId })
  });
  
  if (response.ok) {
    showToast('Added to wishlist', 'success');
  }
}
```

---

## 9. Add Email Notifications

### Using Nodemailer

```bash
npm install nodemailer
```

**Send Order Confirmation:**

```javascript
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

async function sendOrderEmail(email, orderId, totalAmount) {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: `Order Confirmation #${orderId}`,
    html: `
      <h2>Order Confirmed!</h2>
      <p>Order ID: ${orderId}</p>
      <p>Total: $${totalAmount.toFixed(2)}</p>
      <p>Thank you for your purchase!</p>
    `
  };
  
  transporter.sendMail(mailOptions, (err, info) => {
    if (err) console.error('Email error:', err);
    else console.log('Email sent:', info.response);
  });
}
```

Then call after order creation:
```javascript
sendOrderEmail(currentUser.email, orderId, totalAmount);
```

---

## 10. Change Payment Processing

### Integrate Stripe

```bash
npm install stripe
```

**Frontend:**
```html
<script src="https://js.stripe.com/v3/"></script>

<form id="payment-form">
  <div id="card-element"></div>
  <button type="submit" class="btn">Pay Now</button>
</form>
```

**Backend:**
```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

app.post('/api/payment', authenticateToken, async (req, res) => {
  const { amount, token } = req.body;
  
  try {
    const charge = await stripe.charges.create({
      amount: amount * 100,
      currency: 'usd',
      source: token
    });
    
    res.json({ success: true, chargeId: charge.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

---

## 11. Styling Tips

### Make it Mobile-First

The app already has media queries. Add more breakpoints:

```css
/* Tablet */
@media (max-width: 1024px) {
  .products-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* Small devices */
@media (max-width: 480px) {
  .navbar {
    padding: 0.5rem;
  }
  
  .products-grid {
    grid-template-columns: 1fr;
  }
}
```

### Add Dark Mode

```javascript
function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
}
```

```css
body.dark-mode {
  background-color: #1a1a1a;
  color: #e0e0e0;
}

body.dark-mode .navbar {
  background: #0d0d0d;
}
```

---

## 12. Performance Optimizations

### Lazy Load Products

```javascript
let currentPage = 1;
const ITEMS_PER_PAGE = 12;

function loadMoreProducts() {
  const start = (currentPage - 1) * ITEMS_PER_PAGE;
  const end = start + ITEMS_PER_PAGE;
  
  displayProducts(products.slice(start, end));
  currentPage++;
}
```

### Cache API Responses

```javascript
const cache = {};

async function getCachedProducts() {
  if (cache.products) return cache.products;
  
  const response = await fetch(`${API_URL}/products`);
  cache.products = await response.json();
  return cache.products;
}
```

---

## Common Customizations Checklist

- [ ] Change store name and logo
- [ ] Update color scheme
- [ ] Add custom products
- [ ] Add about/contact pages
- [ ] Implement search
- [ ] Add product filters
- [ ] Add reviews system
- [ ] Integrate payment gateway
- [ ] Set up email notifications
- [ ] Optimize for mobile
- [ ] Add dark mode
- [ ] Deploy to production

---

**Happy Customizing! 🎨**

Your unique e-commerce store awaits!
